<?php
define('ROOT', realpath(__DIR__ . '/..') . '/');
require_once ROOT . 'vendor/autoload.php';
require_once ROOT . 'app/includes/product.php';

/* Make sure all the required fields are present */
$required_fields = [ 'database_host', 'database_name', 'database_username', 'database_password', 'url', 'admin_password' ];

foreach($required_fields as $field) {
    if(!isset($_POST[$field])) {
        die(json_encode([
            'status' => 'error',
            'message' => 'One of the required fields are missing.'
        ]));
    }
}

/* Make sure the database details are correct */
$database = @new mysqli(
    $_POST['database_host'],
    $_POST['database_username'],
    $_POST['database_password'],
    $_POST['database_name']
);

if($database->connect_error) {
    die(json_encode([
        'status' => 'error',
        'message' => 'The database connection has failed!'
    ]));
}

    /* Prepare the config file content */
    $config_content =
<<<ALTUM
<?php

define('DATABASE_SERVER',   '{$_POST['database_host']}');
define('DATABASE_USERNAME', '{$_POST['database_username']}');
define('DATABASE_PASSWORD', '{$_POST['database_password']}');
define('DATABASE_NAME',     '{$_POST['database_name']}');
define('SITE_URL',          '{$_POST['url']}');

ALTUM;

/* Write the new config file */
file_put_contents(ROOT . 'app/config/config.php', $config_content);

/* Run SQL */
$dump_content = file_get_contents(ROOT . 'install/dump.sql');

$dump = explode('-- SEPARATOR --', $dump_content);

foreach($dump as $query) {
    $database->query($query);
}

$admin_password = password_hash($_POST['admin_password'], PASSWORD_DEFAULT);
$database->query("UPDATE users SET password='$admin_password', name='Admin' WHERE user_id=1");

die(json_encode([
    'status' => 'success',
    'message' => ''
]));
