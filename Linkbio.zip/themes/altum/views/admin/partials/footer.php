<?php defined('ALTUMCODE') || die() ?>

<footer class="margin-top-3">
    <span class="text-muted"><?= 'Copyright &copy; ' . date('Y') . ' ' . $this->settings->title . '. All rights reserved. Product by 🔥 <a href="https://altumcode.io/" target="_blank">AltumCode</a>' ?></span>
</footer>
