<?php

return ['link', 'text', 'soundcloud', 'youtube', 'twitch', 'vimeo', 'spotify', 'tiktok', 'mail'];
