<?php
define('PRODUCT_NAME', 'LinkinBio');
define('PRODUCT_KEY', 'linkinbio');
define('PRODUCT_DOCUMENTATION_URL', '');
define('PRODUCT_URL', '');
define('PRODUCT_VERSION', '1.0.0 ⚡️');
define('PRODUCT_CODE', '100');
