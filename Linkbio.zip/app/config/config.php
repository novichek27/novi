<?php

define('DATABASE_SERVER',   '');
define('DATABASE_USERNAME', '');
define('DATABASE_PASSWORD', '');
define('DATABASE_NAME',     '');
define('SITE_URL',          '');
